// Demo script
console.log('Deemind demo app loaded');
